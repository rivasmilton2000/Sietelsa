<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/maintenance.php';

function redirigir_mantenimiento_admin(string $estado, string $valor = ''): void
{
    $query = ['mantenimiento_error' => $estado];
    if ($valor !== '') {
        $query['mantenimiento_valor'] = $valor;
    }

    redirigir('/admin/dashboard?' . http_build_query($query));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirigir_mantenimiento_admin('metodo');
}

require_login(['admin', 'gerente', 'tecnico', 'developer']);

$usuario = obtener_usuario_actual();
if (!usuario_puede_gestionar_mantenimiento($usuario)) {
    mostrar_pagina_error(401);
}

$token = trim((string) ($_POST['csrf_token'] ?? ''));
if (!csrf_token_valido($token, 'toggle_mantenimiento')) {
    redirigir_mantenimiento_admin('csrf');
}

$accion = strtolower(trim((string) ($_POST['accion'] ?? '')));
if (!in_array($accion, ['activar', 'desactivar'], true)) {
    redirigir_mantenimiento_admin('accion');
}

global $pdo;

try {
    mantenimiento_actualizar_estado($pdo, $accion === 'activar');
} catch (Throwable $e) {
    redirigir_mantenimiento_admin('db');
}

redirigir('/admin/dashboard?mantenimiento_ok=' . ($accion === 'activar' ? '1' : '0'));
