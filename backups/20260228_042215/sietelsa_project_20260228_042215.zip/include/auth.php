<?php
declare(strict_types=1);

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/cache.php';
require_once __DIR__ . '/db_setup.php';

function invalidar_cache_permisos_usuario(): void
{
    iniciar_sesion_segura();
    unset($_SESSION['permisos_cache']);
}

function usuario_actual_es_admin(): bool
{
    iniciar_sesion_segura();
    $perfil = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
    return $perfil === 'admin' || $perfil === 'administrador';
}

function obtener_ruta_pagina_error(int $codigo): ?string
{
    $paginas = [
        401 => __DIR__ . '/../pages/pages_admin/401.html',
        404 => __DIR__ . '/../pages/pages_admin/404.html',
        500 => __DIR__ . '/../pages/pages_admin/500.html',
    ];

    return $paginas[$codigo] ?? null;
}

function mostrar_pagina_error(int $codigo): void
{
    http_response_code($codigo);

    $ruta = obtener_ruta_pagina_error($codigo);
    if ($ruta !== null && is_file($ruta)) {
        readfile($ruta);
        exit;
    }

    if ($codigo === 401) {
        exit('No autorizado.');
    }

    if ($codigo === 404) {
        exit('Pagina no encontrada.');
    }

    exit('Error interno del servidor.');
}

function iniciar_sesion_segura(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        if (!isset($_SESSION) || !is_array($_SESSION)) {
            $_SESSION = [];
        }
        return;
    }

    if (headers_sent()) {
        mostrar_pagina_error(500);
    }

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        session_set_cookie_params(0, '/', '', $secure, true);
    }

    if (!session_start()) {
        mostrar_pagina_error(500);
    }

    if (!isset($_SESSION) || !is_array($_SESSION)) {
        $_SESSION = [];
    }
}

function usuario_autenticado(): bool
{
    iniciar_sesion_segura();

    if (!isset($_SESSION['usuario']) || !is_array($_SESSION['usuario'])) {
        return false;
    }

    $id = (int) ($_SESSION['usuario']['id'] ?? 0);
    $email = (string) ($_SESSION['usuario']['email'] ?? '');
    return $id > 0 && $email !== '';
}

function obtener_usuario_actual(): ?array
{
    iniciar_sesion_segura();
    return $_SESSION['usuario'] ?? null;
}

function redirigir(string $ruta): void
{
    header('Location: ' . $ruta);
    exit;
}

function require_login(array $perfilesPermitidos = []): void
{
    $timeoutInactividad = 1800;

    iniciar_sesion_segura();

    if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > $timeoutInactividad) {
        cerrar_sesion();
        redirigir('/admin/login?error=timeout');
    }
    $_SESSION['last_activity'] = time();

    if (!usuario_autenticado()) {
        mostrar_pagina_error(401);
    }

    if (!empty($perfilesPermitidos)) {
        $perfil = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
        $permitidosNormalizados = array_map(static fn (string $item): string => strtolower(trim($item)), $perfilesPermitidos);
        if ($perfil !== 'developer' && !in_array($perfil, $permitidosNormalizados, true)) {
            mostrar_pagina_error(401);
        }
    }
}

function tiene_permiso(string $codigoPermiso): bool
{
    global $pdo;
    static $cacheRequest = [];

    if (!usuario_autenticado()) {
        return false;
    }

    $usuarioId = (int) ($_SESSION['usuario']['id'] ?? 0);
    $perfilId = (int) ($_SESSION['usuario']['perfil_id'] ?? 0);
    $perfilNombre = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
    if ($usuarioId <= 0) {
        return false;
    }

    if ($perfilId <= 0) {
        return false;
    }

    $esAdmin = ($perfilNombre === 'admin' || $perfilNombre === 'administrador');

    $cacheRequestKey = $usuarioId . '|' . $perfilId . '|' . $codigoPermiso;
    if (array_key_exists($cacheRequestKey, $cacheRequest)) {
        return (bool) $cacheRequest[$cacheRequestKey];
    }

    $cacheSesion = $_SESSION['permisos_cache'] ?? null;
    if (is_array($cacheSesion)) {
        $cacheTs = (int) ($cacheSesion['ts'] ?? 0);
        $cacheUsuario = (int) ($cacheSesion['usuario_id'] ?? 0);
        $cachePerfil = (int) ($cacheSesion['perfil_id'] ?? 0);
        $cachePermisos = is_array($cacheSesion['permisos'] ?? null) ? $cacheSesion['permisos'] : [];

        if (
            $cacheTs > (time() - 300)
            && $cacheUsuario === $usuarioId
            && $cachePerfil === $perfilId
            && array_key_exists($codigoPermiso, $cachePermisos)
        ) {
            $cacheRequest[$cacheRequestKey] = (bool) $cachePermisos[$codigoPermiso];
            return (bool) $cachePermisos[$codigoPermiso];
        }
    }

    $permitido = null;

    if (function_exists('tabla_existe') && tabla_existe($pdo, 'modulos') && tabla_existe($pdo, 'perfil_modulo')) {
        $stmtModulo = $pdo->prepare(
            'SELECT m.id, m.estado
             FROM modulos m
             WHERE m.nombre_modulo = :codigo
             LIMIT 1'
        );
        $stmtModulo->execute([':codigo' => $codigoPermiso]);
        $modulo = $stmtModulo->fetch();

        if (is_array($modulo)) {
            $moduloId = (int) ($modulo['id'] ?? 0);
            $estadoModulo = strtolower(trim((string) ($modulo['estado'] ?? 'activo')));

            if ($moduloId > 0) {
                if ($estadoModulo !== 'activo') {
                    $permitido = $esAdmin;
                } else {
                    $stmtAsignaciones = $pdo->prepare(
                        'SELECT COUNT(*)
                         FROM perfil_modulo
                         WHERE modulo_id = :modulo_id AND aprobado = 1'
                    );
                    $stmtAsignaciones->execute([':modulo_id' => $moduloId]);
                    $totalAsignaciones = (int) $stmtAsignaciones->fetchColumn();

                    if ($totalAsignaciones <= 0) {
                        $permitido = $esAdmin;
                    } else {
                        $stmtPerfilModulo = $pdo->prepare(
                            'SELECT aprobado
                             FROM perfil_modulo
                             WHERE perfil_id = :perfil_id AND modulo_id = :modulo_id
                             LIMIT 1'
                        );
                        $stmtPerfilModulo->execute([
                            ':perfil_id' => $perfilId,
                            ':modulo_id' => $moduloId,
                        ]);
                        $aprobado = $stmtPerfilModulo->fetchColumn();
                        $permitido = ($aprobado !== false) && ((int) $aprobado === 1);
                    }
                }
            }
        }
    }

    if ($permitido === null) {
        $sqlUsuario = 'SELECT up.permitido
                       FROM usuario_permiso up
                       INNER JOIN permisos p ON p.id = up.permiso_id
                       WHERE up.usuario_id = :usuario_id AND p.codigo = :codigo
                       LIMIT 1';
        $stmtUsuario = $pdo->prepare($sqlUsuario);
        $stmtUsuario->execute([
            ':usuario_id' => $usuarioId,
            ':codigo' => $codigoPermiso,
        ]);
        $permisoUsuario = $stmtUsuario->fetchColumn();

        if ($permisoUsuario !== false) {
            $permitido = (int) $permisoUsuario === 1;
        } else {
            $sqlPerfil = 'SELECT 1
                    FROM perfil_permiso pp
                    INNER JOIN permisos p ON p.id = pp.permiso_id
                    WHERE pp.perfil_id = :perfil_id AND p.codigo = :codigo
                    LIMIT 1';

            $stmt = $pdo->prepare($sqlPerfil);
            $stmt->execute([
                ':perfil_id' => $perfilId,
                ':codigo' => $codigoPermiso,
            ]);
            $permitido = (bool) $stmt->fetchColumn();
        }
    }

    $cacheRequest[$cacheRequestKey] = $permitido;
    $_SESSION['permisos_cache'] = [
        'ts' => time(),
        'usuario_id' => $usuarioId,
        'perfil_id' => $perfilId,
        'permisos' => array_merge(
            is_array($_SESSION['permisos_cache']['permisos'] ?? null) ? $_SESSION['permisos_cache']['permisos'] : [],
            [$codigoPermiso => $permitido]
        ),
    ];
    return $permitido;
}

function require_permiso(string $codigoPermiso): void
{
    if (!tiene_permiso($codigoPermiso)) {
        mostrar_pagina_error(401);
    }
}

function cerrar_sesion(): void
{
    iniciar_sesion_segura();
    invalidar_cache_permisos_usuario();
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}
