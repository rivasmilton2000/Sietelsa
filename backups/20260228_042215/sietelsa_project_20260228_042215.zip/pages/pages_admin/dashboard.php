<?php
declare(strict_types=1);

require_once __DIR__ . '/../../include/auth.php';
require_once __DIR__ . '/../../include/admin_topnav.php';
require_once __DIR__ . '/../../include/admin_sidebar.php';
require_once __DIR__ . '/../../include/csrf.php';
require_once __DIR__ . '/../../include/db_setup.php';
require_once __DIR__ . '/../../include/maintenance.php';
require_once __DIR__ . '/../../include/visitas_analytics.php';

require_login(['admin', 'gerente', 'tecnico', 'developer']);
global $pdo;
asegurar_compatibilidad_auth($pdo);
require_permiso('ver_dashboard');
$usuario = obtener_usuario_actual() ?? [];
$nombre = trim((string) ($usuario['nombre'] ?? ''));
$username = trim((string) ($usuario['username'] ?? ''));
$perfil = trim((string) ($usuario['perfil'] ?? ''));
$puedeGestionarUsuarios = tiene_permiso('gestionar_usuarios');
$puedeGestionarServicios = tiene_permiso('gestionar_servicios');
$puedeGestionarPortafolio = tiene_permiso('gestionar_portafolio');
$puedeGestionarProyectos = tiene_permiso('gestionar_proyectos');
$puedeGestionarNosotros = tiene_permiso('gestionar_nosotros');
$puedeGestionarContacto = tiene_permiso('gestionar_contacto');
$puedeGestionarBackup = tiene_permiso('gestionar_backup');
$puedeGestionarPerfiles = tiene_permiso('gestionar_perfiles');
$puedeGestionarMantenimiento = usuario_puede_gestionar_mantenimiento($usuario);
$puedeGestionarContenido = $puedeGestionarServicios
    || $puedeGestionarPortafolio
    || $puedeGestionarProyectos
    || $puedeGestionarNosotros
    || $puedeGestionarContacto;

$etiquetaSesion = $nombre !== '' ? $nombre : 'Usuario';
if ($username !== '') {
    $etiquetaSesion .= ' (' . $username . ')';
}

function formatear_fecha_dashboard_visitas(string $fechaYmd): string
{
    $fecha = normalizar_fecha_filtro_visita($fechaYmd);
    if ($fecha === null) {
        return $fechaYmd;
    }

    $timestamp = strtotime($fecha);
    if ($timestamp === false) {
        return $fechaYmd;
    }

    return date('d/m/Y', $timestamp);
}

$totalesDashboard = [
    'mensajes_nuevos' => null,
    'proyectos' => null,
    'portafolio' => null,
    'servicios' => null,
];

$hoyFiltro = (new DateTimeImmutable('today'))->format('Y-m-d');
$fechaHastaFiltro = normalizar_fecha_filtro_visita((string) ($_GET['hasta'] ?? '')) ?? $hoyFiltro;
$fechaDesdeDefault = (new DateTimeImmutable($fechaHastaFiltro . ' 00:00:00'))->modify('-29 days')->format('Y-m-d');
$fechaDesdeFiltro = normalizar_fecha_filtro_visita((string) ($_GET['desde'] ?? '')) ?? $fechaDesdeDefault;

if ($fechaDesdeFiltro > $fechaHastaFiltro) {
    $tmp = $fechaDesdeFiltro;
    $fechaDesdeFiltro = $fechaHastaFiltro;
    $fechaHastaFiltro = $tmp;
}

$resumenVisitas = [
    'labels' => [],
    'visitas' => [],
    'paises_distintos' => [],
    'total_periodo' => 0,
    'total_hoy' => 0,
    'top_paises' => [],
    'fecha_inicio' => $fechaDesdeFiltro,
    'fecha_fin' => $fechaHastaFiltro,
];

try {
    asegurar_tabla_visitas_sitio($pdo);
    $resumenVisitas = obtener_resumen_visitas_sitio(
        $pdo,
        30,
        'inicio',
        $fechaDesdeFiltro,
        $fechaHastaFiltro
    );

    if (isset($resumenVisitas['fecha_inicio'])) {
        $fechaDesdeFiltro = (string) $resumenVisitas['fecha_inicio'];
    }
    if (isset($resumenVisitas['fecha_fin'])) {
        $fechaHastaFiltro = (string) $resumenVisitas['fecha_fin'];
    }
} catch (Throwable $e) {
    $resumenVisitas = [
        'labels' => [],
        'visitas' => [],
        'paises_distintos' => [],
        'total_periodo' => 0,
        'total_hoy' => 0,
        'top_paises' => [],
        'fecha_inicio' => $fechaDesdeFiltro,
        'fecha_fin' => $fechaHastaFiltro,
    ];
}

$topPaisesTexto = 'Sin datos de pais para el periodo.';
if (!empty($resumenVisitas['top_paises']) && is_array($resumenVisitas['top_paises'])) {
    $topPaisesFormateados = [];
    foreach ($resumenVisitas['top_paises'] as $itemPais) {
        $pais = trim((string) ($itemPais['pais_nombre'] ?? 'Desconocido'));
        if ($pais === '') {
            $pais = trim((string) ($itemPais['pais_codigo'] ?? 'Desconocido'));
        }
        $total = (int) ($itemPais['total'] ?? 0);
        $topPaisesFormateados[] = $pais . ': ' . $total;
    }

    if (!empty($topPaisesFormateados)) {
        $topPaisesTexto = implode(' | ', $topPaisesFormateados);
    }
}

$actividadChartPayload = [
    'labels' => array_values(is_array($resumenVisitas['labels']) ? $resumenVisitas['labels'] : []),
    'visitas' => array_values(is_array($resumenVisitas['visitas']) ? $resumenVisitas['visitas'] : []),
    'datasetLabelVisitas' => 'Visitas',
];

$mantenimientoActivo = false;
try {
    $mantenimientoActivo = mantenimiento_esta_activo($pdo);
} catch (Throwable $e) {
}

$mensajeMantenimiento = '';
$tipoMensajeMantenimiento = 'success';
$mantenimientoOk = trim((string) ($_GET['mantenimiento_ok'] ?? ''));
$mantenimientoError = trim((string) ($_GET['mantenimiento_error'] ?? ''));

if ($mantenimientoOk === '1') {
    $mensajeMantenimiento = 'Modo mantenimiento activado correctamente.';
} elseif ($mantenimientoOk === '0') {
    $mensajeMantenimiento = 'Modo mantenimiento desactivado correctamente.';
} elseif ($mantenimientoError !== '') {
    $tipoMensajeMantenimiento = 'danger';
    $mensajesErrorMantenimiento = [
        'metodo' => 'Solicitud no permitida para mantenimiento.',
        'csrf' => 'Token CSRF invalido o expirado. Intenta de nuevo.',
        'accion' => 'Accion de mantenimiento no valida.',
        'db' => 'No se pudo guardar el estado de mantenimiento en la base de datos.',
    ];
    $mensajeMantenimiento = $mensajesErrorMantenimiento[$mantenimientoError] ?? 'Ocurrio un error al actualizar mantenimiento.';
}

$csrfMantenimiento = $puedeGestionarMantenimiento ? csrf_token('toggle_mantenimiento') : '';

if ($puedeGestionarContenido) {
    try {
        if ($puedeGestionarContacto) {
            asegurar_tabla_contacto_mensajes($pdo);
            $stmtMensajesNuevos = $pdo->query("SELECT COUNT(*) FROM contacto_mensajes WHERE estado = 'nuevo'");
            $totalesDashboard['mensajes_nuevos'] = (int) ($stmtMensajesNuevos ? $stmtMensajesNuevos->fetchColumn() : 0);
        }

        if ($puedeGestionarProyectos) {
            asegurar_tabla_proyectos($pdo);
            $stmtProyectos = $pdo->query('SELECT COUNT(*) FROM proyectos');
            $totalesDashboard['proyectos'] = (int) ($stmtProyectos ? $stmtProyectos->fetchColumn() : 0);
        }

        if ($puedeGestionarPortafolio) {
            asegurar_tabla_portafolio($pdo);
            $stmtPortafolio = $pdo->query('SELECT COUNT(*) FROM portafolio');
            $totalesDashboard['portafolio'] = (int) ($stmtPortafolio ? $stmtPortafolio->fetchColumn() : 0);
        }

        if ($puedeGestionarServicios) {
            asegurar_tabla_servicios($pdo);
            $stmtServicios = $pdo->query('SELECT COUNT(*) FROM servicios');
            $totalesDashboard['servicios'] = (int) ($stmtServicios ? $stmtServicios->fetchColumn() : 0);
        }
    } catch (Throwable $e) {
        $totalesDashboard = [
            'mensajes_nuevos' => null,
            'proyectos' => null,
            'portafolio' => null,
            'servicios' => null,
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="Panel administrativo Sietelsa" />
        <meta name="author" content="Sietelsa" />
        <title>Dashboard | Sietelsa</title>
        <link rel="icon" type="image/jpeg" href="../../assets/img/logos/sietelsaPestana.jpg" />
        <link href="/admin/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
                <?php render_admin_topnav($pdo, $usuario, $etiquetaSesion, $perfil, $puedeGestionarContacto); ?>
        <div id="layoutSidenav">
            <?php render_admin_sidebar($pdo, isset($usuario) && is_array($usuario) ? $usuario : (isset($usuarioSesion) && is_array($usuarioSesion) ? $usuarioSesion : []), $etiquetaSesion); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Panel de control</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <?php if ($mensajeMantenimiento !== ''): ?>
                            <div class="alert alert-<?php echo $tipoMensajeMantenimiento === 'success' ? 'success' : 'danger'; ?>" role="alert">
                                <?php echo htmlspecialchars($mensajeMantenimiento, ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($puedeGestionarMantenimiento): ?>
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-screwdriver-wrench me-1"></i>
                                    Modo mantenimiento
                                </div>
                                <div class="card-body d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                                    <div>
                                        <div class="fw-semibold mb-1">
                                            Estado actual:
                                            <span class="badge <?php echo $mantenimientoActivo ? 'bg-danger' : 'bg-success'; ?>">
                                                <?php echo $mantenimientoActivo ? 'ACTIVO' : 'INACTIVO'; ?>
                                            </span>
                                        </div>
                                        <div class="text-muted small">
                                            Publico: <?php echo $mantenimientoActivo ? 'maintenance.php (503)' : 'sitio habilitado'; ?>.
                                            Admin/developer autenticados mantienen acceso normal.
                                        </div>
                                    </div>
                                    <form action="/admin/acciones/mantenimiento" method="post" class="d-inline-flex">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfMantenimiento, ENT_QUOTES, 'UTF-8'); ?>" />
                                        <input type="hidden" name="accion" value="<?php echo $mantenimientoActivo ? 'desactivar' : 'activar'; ?>" />
                                        <button class="btn <?php echo $mantenimientoActivo ? 'btn-success' : 'btn-warning'; ?>" type="submit">
                                            <?php echo $mantenimientoActivo ? 'Desactivar mantenimiento' : 'Activar mantenimiento'; ?>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">
                                        <div class="small text-uppercase">Mensajes nuevos</div>
                                        <div class="fs-2 fw-bold">
                                            <?php echo $totalesDashboard['mensajes_nuevos'] === null ? '--' : (int) $totalesDashboard['mensajes_nuevos']; ?>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo $puedeGestionarContacto ? '/admin/contacto?estado=nuevo' : '#'; ?>">Ver detalle</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">
                                        <div class="small text-uppercase">Proyectos</div>
                                        <div class="fs-2 fw-bold">
                                            <?php echo $totalesDashboard['proyectos'] === null ? '--' : (int) $totalesDashboard['proyectos']; ?>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo $puedeGestionarProyectos ? '/admin/proyectos' : '#'; ?>">Ver detalle</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">
                                        <div class="small text-uppercase">Portafolio</div>
                                        <div class="fs-2 fw-bold">
                                            <?php echo $totalesDashboard['portafolio'] === null ? '--' : (int) $totalesDashboard['portafolio']; ?>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo $puedeGestionarPortafolio ? '/admin/portafolio' : '#'; ?>">Ver detalle</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">
                                        <div class="small text-uppercase">Servicios</div>
                                        <div class="fs-2 fw-bold">
                                            <?php echo $totalesDashboard['servicios'] === null ? '--' : (int) $totalesDashboard['servicios']; ?>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="<?php echo $puedeGestionarServicios ? '/admin/servicios' : '#'; ?>">Ver detalle</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-chart-area me-1"></i>
                                Actividad reciente de visitas
                            </div>
                            <div class="card-body">
                                <form method="get" class="row g-3 align-items-end mb-3">
                                    <div class="col-md-4">
                                        <label class="form-label mb-1" for="filtro_desde">Desde</label>
                                        <input
                                            class="form-control"
                                            type="date"
                                            id="filtro_desde"
                                            name="desde"
                                            value="<?php echo htmlspecialchars($fechaDesdeFiltro, ENT_QUOTES, 'UTF-8'); ?>"
                                        />
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label mb-1" for="filtro_hasta">Hasta</label>
                                        <input
                                            class="form-control"
                                            type="date"
                                            id="filtro_hasta"
                                            name="hasta"
                                            value="<?php echo htmlspecialchars($fechaHastaFiltro, ENT_QUOTES, 'UTF-8'); ?>"
                                        />
                                    </div>
                                    <div class="col-md-4 d-flex gap-2">
                                        <button type="submit" class="btn btn-primary flex-fill">Filtrar</button>
                                        <a href="/admin/dashboard" class="btn btn-outline-secondary">Limpiar</a>
                                    </div>
                                </form>

                                <canvas id="myAreaChart" width="100%" height="30"></canvas>
                                <div class="mt-3 small text-muted">
                                    Periodo: <strong><?php echo htmlspecialchars(formatear_fecha_dashboard_visitas($fechaDesdeFiltro), ENT_QUOTES, 'UTF-8'); ?></strong>
                                    al
                                    <strong><?php echo htmlspecialchars(formatear_fecha_dashboard_visitas($fechaHastaFiltro), ENT_QUOTES, 'UTF-8'); ?></strong>
                                </div>
                                <div class="small text-muted">
                                    Total del periodo: <strong><?php echo (int) ($resumenVisitas['total_periodo'] ?? 0); ?></strong>
                                    | Hoy: <strong><?php echo (int) ($resumenVisitas['total_hoy'] ?? 0); ?></strong>
                                </div>
                                <div class="small text-muted">
                                    Paises de procedencia (top 5): <?php echo htmlspecialchars($topPaisesTexto, ENT_QUOTES, 'UTF-8'); ?>
                                </div>
                            </div>
                            <div class="card-footer small text-muted">Actualizado automaticamente</div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">&copy;Derechos reservados SIETELSA S.A. DE C.V <?php echo date('Y'); ?></div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="/admin/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script>
            window.dashboardActividadData = <?php echo json_encode($actividadChartPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
        </script>
        <script src="/admin/assets/demo/chart-area-demo.js"></script>
    </body>
</html>
