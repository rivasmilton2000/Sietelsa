-- Respaldo SQL generado por Sietelsa
-- Fecha: 2026-02-25 07:16:16
-- Base de datos: sietelsa_db

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------
-- Tabla: contacto_mensajes
-- --------------------------------------------------
DROP TABLE IF EXISTS `contacto_mensajes`;
CREATE TABLE `contacto_mensajes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `email` varchar(120) NOT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `asunto` varchar(180) DEFAULT NULL,
  `mensaje` text NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'nuevo',
  `respuesta_admin` text DEFAULT NULL,
  `respondido_por_usuario_id` int(10) unsigned DEFAULT NULL,
  `respondido_en` datetime DEFAULT NULL,
  `notificado` tinyint(1) NOT NULL DEFAULT 0,
  `error_notificacion` varchar(255) DEFAULT NULL,
  `ip_origen` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_contacto_estado_creado` (`estado`,`creado_en`),
  KEY `fk_contacto_respondido_por_usuario` (`respondido_por_usuario_id`),
  CONSTRAINT `fk_contacto_respondido_por_usuario` FOREIGN KEY (`respondido_por_usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------
-- Tabla: nosotros
-- --------------------------------------------------
DROP TABLE IF EXISTS `nosotros`;
CREATE TABLE `nosotros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(120) NOT NULL,
  `descripcion_1` text DEFAULT NULL,
  `descripcion_2` text DEFAULT NULL,
  `descripcion_3` text DEFAULT NULL,
  `imagen_path` varchar(255) DEFAULT NULL,
  `orden` int(10) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `nosotros` (`id`, `titulo`, `descripcion_1`, `descripcion_2`, `descripcion_3`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (1, 'NOSOTROS', 'SIETELSA, S.A. DE C.V. Nace en 2005 con la objetivo de otorgar soluciones de alto nivel a empresas nacionales y   multinacionales,  para todo tipo de proyectos de Telecomunicaciones y Electricidad.', 'A través de los años, la empresa ha desempeñado trabajos con eficacia y eficiencia, impulsando siempre calidad de servicio dentro de los plazos solicitados por nuestros clientes, todo esto nos ha permitido lograr un gran crecimiento.', 'Presencia en Centro América: El Salvador (HC), Guatemala, Honduras y Nicaragua', 'assets/img/about/upload_nosotros_20260224_205551_d2a4db7c.png', 1, 1, '2026-02-24 13:42:27', '2026-02-24 13:56:37');

-- --------------------------------------------------
-- Tabla: perfil_permiso
-- --------------------------------------------------
DROP TABLE IF EXISTS `perfil_permiso`;
CREATE TABLE `perfil_permiso` (
  `perfil_id` int(10) unsigned NOT NULL,
  `permiso_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`perfil_id`,`permiso_id`),
  KEY `fk_perfil_permiso_permiso` (`permiso_id`),
  CONSTRAINT `fk_perfil_permiso_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_perfil_permiso_permiso` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 1);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 2);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 3);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 4);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 949);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 950);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 951);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 952);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 953);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (1, 954);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 1);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 3);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 4);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 949);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 950);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 951);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 952);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (2, 953);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (3, 1);
INSERT INTO `perfil_permiso` (`perfil_id`, `permiso_id`) VALUES (4, 1);

-- --------------------------------------------------
-- Tabla: perfiles
-- --------------------------------------------------
DROP TABLE IF EXISTS `perfiles`;
CREATE TABLE `perfiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=1057 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `perfiles` (`id`, `nombre`, `descripcion`, `activo`, `creado_en`) VALUES (1, 'admin', 'Control total del sistema', 1, '2026-02-23 18:27:50');
INSERT INTO `perfiles` (`id`, `nombre`, `descripcion`, `activo`, `creado_en`) VALUES (2, 'gerente', 'Gestion y reportes', 1, '2026-02-23 18:27:50');
INSERT INTO `perfiles` (`id`, `nombre`, `descripcion`, `activo`, `creado_en`) VALUES (3, 'tecnico', 'Operacion tecnica', 1, '2026-02-23 18:27:50');
INSERT INTO `perfiles` (`id`, `nombre`, `descripcion`, `activo`, `creado_en`) VALUES (4, 'cliente', 'Acceso basico', 1, '2026-02-23 18:27:50');

-- --------------------------------------------------
-- Tabla: permisos
-- --------------------------------------------------
DROP TABLE IF EXISTS `permisos`;
CREATE TABLE `permisos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(80) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=1219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (1, 'ver_dashboard', 'Puede ingresar al dashboard');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (2, 'gestionar_usuarios', 'Puede crear o editar usuarios');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (3, 'ver_reportes', 'Puede ver reportes');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (4, 'gestionar_contenido', 'Permiso general heredado para gestionar contenido');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (949, 'gestionar_servicios', 'Puede administrar el modulo de servicios');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (950, 'gestionar_portafolio', 'Puede administrar el modulo de portafolio');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (951, 'gestionar_proyectos', 'Puede administrar el modulo de proyectos');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (952, 'gestionar_nosotros', 'Puede administrar el modulo de nosotros');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (953, 'gestionar_contacto', 'Puede gestionar los mensajes de contacto');
INSERT INTO `permisos` (`id`, `codigo`, `descripcion`) VALUES (954, 'gestionar_backup', 'Puede generar y descargar respaldos SQL');

-- --------------------------------------------------
-- Tabla: portafolio
-- --------------------------------------------------
DROP TABLE IF EXISTS `portafolio`;
CREATE TABLE `portafolio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(120) NOT NULL,
  `descripcion` varchar(1200) DEFAULT NULL,
  `cliente` varchar(120) DEFAULT NULL,
  `categoria` varchar(120) DEFAULT NULL,
  `imagen_path` varchar(255) NOT NULL,
  `orden` int(10) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (2, 'Redes de Telecomunicación móvil', 'Nuestros Servicios de Telecomunicación Móvil\r\n\r\nInstalación, Comisionamiento y Mantenimiento de Radiobases 2G, 3G y 4G\r\n\r\nInstalación y Comisionamiento de Enlaces de Microondas\r\n\r\nInstalación y Mantenimiento de Redes de Fibra Óptica\r\n\r\nConstrucción y Mantenimiento de Torres y Monopolos de hasta 60 Metros\r\n\r\nInstalación, Comisionamiento y Mantenimiento de Sistemas de Energía para Telecomunicaciones\r\n\r\nInstalación y Mantenimiento de Motogeneradores de hasta 750 KVA con Sistema de Transferencia\r\n\r\nInstalación y Mantenimiento de Tableros de Distribución de Baja Tensión y Sistemas de Rectificación', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_171645_fd06c68f.jpg', 1, 1, '2026-02-24 10:16:45', '2026-02-24 10:16:45');
INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (3, 'Sistemas Eléctricos de baja y media tensión', 'Nuestros Servicios en Sistemas Eléctricos\r\n\r\nDiseño, Supervisión y Construcción de Líneas Eléctricas\r\n\r\nMedición, Instalación y Mantenimiento de Redes de Tierra\r\n\r\nDiseño, Instalación y Mantenimiento de Subestaciones Eléctricas (Media y Alta Tensión)\r\n\r\nInstalación de Acometidas Eléctricas e Instalaciones Residenciales\r\n\r\nInstalación de Sistemas de Automatización\r\n\r\nConstrucción, Mantenimiento y Poda de Sistemas de Línea\r\n\r\nObras Civiles (Bases, Cerramientos de Subestaciones, Remodelaciones y Otros)', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_200350_98dd8465.jpg', 2, 1, '2026-02-24 13:03:50', '2026-02-24 13:03:50');
INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (4, 'Centrales de Generación solar', 'Nuestros Servicios en Centrales de Generación Solar\r\n\r\nDiseño y Construcción de Centrales Solares de 1 a 25 MW\r\n\r\nDesarrollo, Permisología y Ejecución de Planos Constructivos\r\n\r\nMontaje de Herrajería y Paneles Solares\r\n\r\nCanalizaciones y Cableado Eléctrico y de Comunicación, incluyendo Fibra Óptica\r\n\r\nDiseño y Construcción de Subestaciones para Centrales de Energía Solar', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_201113_d11ea5e5.webp', 3, 1, '2026-02-24 13:11:13', '2026-02-24 13:11:13');
INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (5, 'Obras Cíviles generales', 'Nuestros Servicios en Construcción y Acabados Residenciales\r\n\r\nDiseño de Fachadas\r\n\r\nConstrucciones Residenciales\r\n\r\nTrabajos de Pintura Residencial', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_201314_ef3ad251.jpg', 4, 1, '2026-02-24 13:13:14', '2026-02-24 13:13:14');
INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (6, 'Servicios de Radiofrecuencias', 'Nuestros Servicios en Radiofrecuencia\r\n\r\nDiseño de Radioenlaces de Microondas en Banda Libre y Licenciada\r\n\r\nAuditoría de Redes de Microondas Existentes y Optimización de Licenciamiento\r\n\r\nDiseño, Sintonía Inicial y Optimización de Bases de Comunicación Móvil (DECT, 2G, 3G y 4G)\r\n\r\nAnálisis de Espectro y Asesoría en Temas de Interferencia ante SIGET\r\n\r\nMedición de Sistemas de Tierra en Redes de Telecomunicaciones\r\n\r\nAuditoría de Ocupación de Torres\r\n\r\nDiseño de Redes WiFi 5 GHz Outdoor y Enlaces Punto a Multipunto', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_201620_324728e7.jpg', 5, 1, '2026-02-24 13:16:20', '2026-02-24 13:16:20');
INSERT INTO `portafolio` (`id`, `titulo`, `descripcion`, `cliente`, `categoria`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (7, 'Servicios de Fibra óptica', 'Nuestros Servicios en Fibra Óptica\r\n\r\nImplementación de Anillos de Fibra Óptica\r\n\r\nDiseño y Colocación de Fibra Óptica\r\n\r\nReparación de Enlaces de Fibra Óptica', NULL, NULL, 'assets/img/portfolio/upload_portafolio_20260224_201835_d39fb3f1.jpg', 6, 1, '2026-02-24 13:18:35', '2026-02-24 13:18:35');

-- --------------------------------------------------
-- Tabla: portafolio_imagenes
-- --------------------------------------------------
DROP TABLE IF EXISTS `portafolio_imagenes`;
CREATE TABLE `portafolio_imagenes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `portafolio_id` int(10) unsigned NOT NULL,
  `imagen_path` varchar(255) NOT NULL,
  `orden` int(10) unsigned NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_portafolio_imagenes_portafolio` (`portafolio_id`),
  CONSTRAINT `fk_portafolio_imagenes_portafolio` FOREIGN KEY (`portafolio_id`) REFERENCES `portafolio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (1, 2, 'assets/img/portfolio/upload_portafolio_20260224_171645_fd06c68f.jpg', 1, '2026-02-24 10:30:04');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (2, 2, 'assets/img/portfolio/upload_portafolio_20260224_195932_7305ce61.webp', 2, '2026-02-24 12:59:32');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (3, 2, 'assets/img/portfolio/upload_portafolio_20260224_195944_d78aa6a9.webp', 3, '2026-02-24 12:59:44');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (4, 3, 'assets/img/portfolio/upload_portafolio_20260224_200350_98dd8465.jpg', 1, '2026-02-24 13:03:50');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (5, 4, 'assets/img/portfolio/upload_portafolio_20260224_201113_d11ea5e5.webp', 1, '2026-02-24 13:11:13');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (6, 5, 'assets/img/portfolio/upload_portafolio_20260224_201314_ef3ad251.jpg', 1, '2026-02-24 13:13:14');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (7, 6, 'assets/img/portfolio/upload_portafolio_20260224_201620_324728e7.jpg', 1, '2026-02-24 13:16:20');
INSERT INTO `portafolio_imagenes` (`id`, `portafolio_id`, `imagen_path`, `orden`, `creado_en`) VALUES (8, 7, 'assets/img/portfolio/upload_portafolio_20260224_201835_d39fb3f1.jpg', 1, '2026-02-24 13:18:35');

-- --------------------------------------------------
-- Tabla: proyectos
-- --------------------------------------------------
DROP TABLE IF EXISTS `proyectos`;
CREATE TABLE `proyectos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(120) NOT NULL,
  `portafolio_id` int(10) unsigned DEFAULT NULL,
  `imagen_path` varchar(255) NOT NULL,
  `orden` int(10) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_proyectos_portafolio` (`portafolio_id`),
  CONSTRAINT `fk_proyectos_portafolio` FOREIGN KEY (`portafolio_id`) REFERENCES `portafolio` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `proyectos` (`id`, `titulo`, `portafolio_id`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (1, 'Redes móviles', 2, 'assets/img/proyectos/upload_proyecto_20260224_211927_9ea9d812.png', 1, 1, '2026-02-24 14:19:27', '2026-02-24 14:35:27');
INSERT INTO `proyectos` (`id`, `titulo`, `portafolio_id`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (2, 'Sistemas eléctricos', 3, 'assets/img/proyectos/upload_proyecto_20260224_213902_a956ff5b.png', 2, 1, '2026-02-24 14:39:02', '2026-02-24 14:39:02');
INSERT INTO `proyectos` (`id`, `titulo`, `portafolio_id`, `imagen_path`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (3, 'Centrales Solares', 4, 'assets/img/proyectos/upload_proyecto_20260224_213953_8a911232.png', 3, 1, '2026-02-24 14:39:53', '2026-02-24 14:39:53');

-- --------------------------------------------------
-- Tabla: servicios
-- --------------------------------------------------
DROP TABLE IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(120) NOT NULL,
  `descripcion` varchar(1000) DEFAULT NULL,
  `icono` varchar(80) NOT NULL DEFAULT 'fa-circle-info',
  `orden` int(10) unsigned NOT NULL DEFAULT 0,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (2, 'Redes de Telecomunicación móvil', NULL, 'fa-network-wired', 1, 1, '2026-02-23 23:56:58', '2026-02-23 23:58:11');
INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (3, 'Sistemas Eléctricos de baja y media tensión', NULL, 'fa-gears', 2, 1, '2026-02-23 23:58:49', '2026-02-23 23:59:49');
INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (4, 'Centrales de Generación solar', NULL, 'fa-bolt', 3, 1, '2026-02-24 00:06:00', '2026-02-24 00:06:00');
INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (5, 'Obras Civiles generales', NULL, 'fa-shield-halved', 4, 1, '2026-02-24 00:16:59', '2026-02-24 00:16:59');
INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (6, 'Servicios de Radiofrecuencias', NULL, 'fa-wifi', 5, 1, '2026-02-24 00:17:55', '2026-02-24 00:17:55');
INSERT INTO `servicios` (`id`, `titulo`, `descripcion`, `icono`, `orden`, `activo`, `creado_en`, `actualizado_en`) VALUES (7, 'Servicios de Fibra óptica', NULL, 'fa-database', 6, 1, '2026-02-24 00:18:14', '2026-02-24 00:18:14');

-- --------------------------------------------------
-- Tabla: usuario_permiso
-- --------------------------------------------------
DROP TABLE IF EXISTS `usuario_permiso`;
CREATE TABLE `usuario_permiso` (
  `usuario_id` int(10) unsigned NOT NULL,
  `permiso_id` int(10) unsigned NOT NULL,
  `permitido` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`usuario_id`,`permiso_id`),
  KEY `fk_usuario_permiso_permiso` (`permiso_id`),
  CONSTRAINT `fk_usuario_permiso_permiso` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usuario_permiso_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------
-- Tabla: usuarios
-- --------------------------------------------------
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(120) NOT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `foto_path` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('admin','usuario') NOT NULL DEFAULT 'usuario',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ultimo_login` datetime DEFAULT NULL,
  `intentos_fallidos` int(10) unsigned NOT NULL DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `perfil_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `uq_usuarios_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id`, `nombre`, `username`, `email`, `telefono`, `direccion`, `foto_path`, `password_hash`, `rol`, `activo`, `creado_en`, `actualizado_en`, `ultimo_login`, `intentos_fallidos`, `bloqueado_hasta`, `perfil_id`) VALUES (1, 'Administrador', 'admin', 'admin@sietelsa.com', NULL, NULL, NULL, '$2y$10$7m26pxA2Pw0BSeZgMIX7cuSQ63oWW3XTp9kCCVm98WO/42MLQU8qe', 'admin', 1, '2026-02-23 14:12:51', '2026-02-25 00:16:16', NULL, 0, NULL, 1);

-- --------------------------------------------------
-- Tabla: visitas_sitio
-- --------------------------------------------------
DROP TABLE IF EXISTS `visitas_sitio`;
CREATE TABLE `visitas_sitio` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pagina` varchar(120) NOT NULL DEFAULT 'inicio',
  `ip_origen` varchar(45) DEFAULT NULL,
  `pais_codigo` char(2) DEFAULT NULL,
  `pais_nombre` varchar(120) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_visitas_creado` (`creado_en`),
  KEY `idx_visitas_pagina_creado` (`pagina`,`creado_en`),
  KEY `idx_visitas_pais_creado` (`pais_codigo`,`creado_en`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (1, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 21:54:16');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (2, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 22:06:38');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (3, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', '2026-02-24 22:20:37');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (4, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:23:22');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (5, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:24:43');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (6, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:25:39');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (7, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:26:39');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (8, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 22:27:58');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (9, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:30:14');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (10, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:38:44');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (11, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:38:59');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (12, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:42:39');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (13, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:46:37');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (14, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:46:53');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (15, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:51:55');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (16, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', '2026-02-24 22:52:03');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (17, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', '2026-02-24 22:52:46');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (18, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 22:57:24');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (19, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', '2026-02-24 23:06:07');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (20, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '2026-02-24 23:06:18');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (21, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 23:06:49');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (22, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-02-24 23:08:24');
INSERT INTO `visitas_sitio` (`id`, `pagina`, `ip_origen`, `pais_codigo`, `pais_nombre`, `user_agent`, `creado_en`) VALUES (23, 'inicio', '::1', NULL, 'Desconocido', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-25 00:13:52');

SET FOREIGN_KEY_CHECKS=1;
