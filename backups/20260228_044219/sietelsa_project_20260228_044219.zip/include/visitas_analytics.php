<?php
declare(strict_types=1);

require_once __DIR__ . '/db_setup.php';
require_once __DIR__ . '/cache.php';

function normalizar_codigo_pais_visita(?string $codigo): string
{
    $codigo = strtoupper(trim((string) $codigo));
    if ($codigo === '' || preg_match('/^[A-Z]{2}$/', $codigo) !== 1) {
        return '';
    }

    return $codigo;
}

function nombre_pais_desde_codigo_visita(string $codigo): string
{
    $codigo = normalizar_codigo_pais_visita($codigo);
    if ($codigo === '') {
        return '';
    }

    if (class_exists('Locale')) {
        $nombre = Locale::getDisplayRegion('-' . $codigo, 'es');
        if (is_string($nombre)) {
            $nombre = trim($nombre);
            if ($nombre !== '') {
                return $nombre;
            }
        }
    }

    return $codigo;
}

function detectar_pais_visita(): array
{
    $codigo = '';
    $fuentesCodigo = [
        (string) ($_SERVER['HTTP_CF_IPCOUNTRY'] ?? ''),
        (string) ($_SERVER['GEOIP_COUNTRY_CODE'] ?? ''),
        (string) ($_SERVER['HTTP_X_COUNTRY_CODE'] ?? ''),
    ];

    foreach ($fuentesCodigo as $candidato) {
        $normalizado = normalizar_codigo_pais_visita($candidato);
        if ($normalizado !== '') {
            $codigo = $normalizado;
            break;
        }
    }

    $nombre = trim((string) ($_SERVER['GEOIP_COUNTRY_NAME'] ?? ''));
    if ($nombre === '' && $codigo !== '') {
        $nombre = nombre_pais_desde_codigo_visita($codigo);
    }

    if ($nombre === '') {
        $nombre = 'Desconocido';
    }

    return [
        'codigo' => $codigo,
        'nombre' => $nombre,
    ];
}

function obtener_ip_cliente_visita(): string
{
    $candidatos = [
        (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? ''),
        (string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''),
        (string) ($_SERVER['HTTP_CLIENT_IP'] ?? ''),
        (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
    ];

    foreach ($candidatos as $valor) {
        if ($valor === '') {
            continue;
        }

        $partes = array_map('trim', explode(',', $valor));
        foreach ($partes as $ip) {
            if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                return $ip;
            }
        }
    }

    return '';
}

function formatear_label_dia_visita(string $fechaYmd): string
{
    $timestamp = strtotime($fechaYmd);
    if ($timestamp === false) {
        return $fechaYmd;
    }

    return date('d/m', $timestamp);
}

function normalizar_fecha_filtro_visita(?string $fechaRaw): ?string
{
    $fechaRaw = trim((string) $fechaRaw);
    if ($fechaRaw === '') {
        return null;
    }

    $fecha = DateTimeImmutable::createFromFormat('Y-m-d', $fechaRaw);
    if (!$fecha instanceof DateTimeImmutable) {
        return null;
    }

    if ($fecha->format('Y-m-d') !== $fechaRaw) {
        return null;
    }

    return $fechaRaw;
}

function registrar_visita_sitio(PDO $pdo, string $pagina = 'inicio'): void
{
    $pagina = trim($pagina);
    if ($pagina === '') {
        $pagina = 'inicio';
    }

    $pagina = substr($pagina, 0, 120);
    $ip = obtener_ip_cliente_visita();
    $pais = detectar_pais_visita();
    $userAgent = trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    $userAgent = $userAgent !== '' ? substr($userAgent, 0, 255) : null;

    $stmt = $pdo->prepare(
        'INSERT INTO visitas_sitio (pagina, ip_origen, pais_codigo, pais_nombre, user_agent)
         VALUES (:pagina, :ip_origen, :pais_codigo, :pais_nombre, :user_agent)'
    );
    $stmt->execute([
        ':pagina' => $pagina,
        ':ip_origen' => $ip !== '' ? $ip : null,
        ':pais_codigo' => $pais['codigo'] !== '' ? $pais['codigo'] : null,
        ':pais_nombre' => $pais['nombre'] !== '' ? $pais['nombre'] : null,
        ':user_agent' => $userAgent,
    ]);
}

function registrar_visita_sitio_controlado(PDO $pdo, string $pagina = 'inicio', int $minIntervaloSegundos = 900): void
{
    $minIntervaloSegundos = max(60, $minIntervaloSegundos);
    $ip = obtener_ip_cliente_visita();
    $ua = trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    $fingerprint = sha1($pagina . '|' . $ip . '|' . $ua);
    $cacheKey = 'visit_throttle_v1|' . $fingerprint;

    if (sietelsa_cache_get('analytics', $cacheKey) !== null) {
        return;
    }

    registrar_visita_sitio($pdo, $pagina);
    sietelsa_cache_set('analytics', $cacheKey, 1, $minIntervaloSegundos);
}

function obtener_paises_disponibles_visitas(PDO $pdo, string $pagina = 'inicio'): array
{
    $pagina = trim($pagina);
    if ($pagina === '') {
        $pagina = 'inicio';
    }

    $stmtPaises = $pdo->prepare(
        'SELECT COALESCE(NULLIF(TRIM(pais_codigo), \'\'), \'??\') AS pais_codigo,
                COALESCE(NULLIF(TRIM(pais_nombre), \'\'), \'Desconocido\') AS pais_nombre,
                COUNT(*) AS total
         FROM visitas_sitio
         WHERE pagina = :pagina
         GROUP BY COALESCE(NULLIF(TRIM(pais_codigo), \'\'), \'??\'),
                  COALESCE(NULLIF(TRIM(pais_nombre), \'\'), \'Desconocido\')
         ORDER BY total DESC, pais_nombre ASC'
    );
    $stmtPaises->execute([
        ':pagina' => $pagina,
    ]);

    $paises = [];
    foreach ($stmtPaises->fetchAll() as $fila) {
        $codigo = strtoupper(trim((string) ($fila['pais_codigo'] ?? '??')));
        if ($codigo === '') {
            $codigo = '??';
        }

        $nombre = trim((string) ($fila['pais_nombre'] ?? 'Desconocido'));
        if ($nombre === '') {
            $nombre = 'Desconocido';
        }

        $paises[] = [
            'pais_codigo' => $codigo,
            'pais_nombre' => $nombre,
            'total' => (int) ($fila['total'] ?? 0),
        ];
    }

    return $paises;
}

function obtener_resumen_visitas_sitio(
    PDO $pdo,
    int $dias = 14,
    string $pagina = 'inicio',
    ?string $fechaInicio = null,
    ?string $fechaFin = null,
    string $paisCodigoFiltro = ''
): array
{
    $dias = max(1, min(365, $dias));
    $pagina = trim($pagina);
    if ($pagina === '') {
        $pagina = 'inicio';
    }

    $hoy = new DateTimeImmutable('today');
    $fechaFinNormalizada = normalizar_fecha_filtro_visita($fechaFin) ?? $hoy->format('Y-m-d');
    $fin = new DateTimeImmutable($fechaFinNormalizada . ' 00:00:00');

    $fechaInicioNormalizada = normalizar_fecha_filtro_visita($fechaInicio);
    if ($fechaInicioNormalizada === null) {
        $inicio = $fin->modify('-' . ($dias - 1) . ' days');
    } else {
        $inicio = new DateTimeImmutable($fechaInicioNormalizada . ' 00:00:00');
    }

    if ($inicio > $fin) {
        $tmp = $inicio;
        $inicio = $fin;
        $fin = $tmp;
    }

    $diasRango = ((int) $inicio->diff($fin)->format('%a')) + 1;
    if ($diasRango > 366) {
        $inicio = $fin->modify('-365 days');
        $diasRango = 366;
    }

    $inicioSql = $inicio->format('Y-m-d 00:00:00');
    $finMasUnDiaSql = $fin->modify('+1 day')->format('Y-m-d 00:00:00');
    $hoyClave = $hoy->format('Y-m-d');

    $visitasPorDia = [];
    $paisesPorDia = [];
    for ($i = 0; $i < $diasRango; $i++) {
        $fecha = $inicio->modify('+' . $i . ' days')->format('Y-m-d');
        $visitasPorDia[$fecha] = 0;
        $paisesPorDia[$fecha] = 0;
    }

    $paisCodigoFiltro = strtoupper(trim($paisCodigoFiltro));
    if ($paisCodigoFiltro !== '??') {
        $paisCodigoFiltro = normalizar_codigo_pais_visita($paisCodigoFiltro);
    }

    $wherePaisSql = '';
    $paramPais = [];
    if ($paisCodigoFiltro === '??') {
        $wherePaisSql = " AND COALESCE(NULLIF(TRIM(pais_codigo), ''), '??') = '??'";
    } elseif ($paisCodigoFiltro !== '') {
        $wherePaisSql = ' AND pais_codigo = :pais_codigo';
        $paramPais[':pais_codigo'] = $paisCodigoFiltro;
    }

    $sqlSerie = 'SELECT DATE(creado_en) AS fecha,
                        COUNT(*) AS total_visitas,
                        COUNT(DISTINCT COALESCE(NULLIF(TRIM(pais_codigo), \'\'), \'??\')) AS total_paises
                 FROM visitas_sitio
                 WHERE pagina = :pagina
                   AND creado_en >= :inicio
                   AND creado_en < :fin_mas_uno'
                 . $wherePaisSql
                 . ' GROUP BY DATE(creado_en)';
    $stmtSerie = $pdo->prepare($sqlSerie);
    $paramsSerie = [
        ':pagina' => $pagina,
        ':inicio' => $inicioSql,
        ':fin_mas_uno' => $finMasUnDiaSql,
    ] + $paramPais;
    $stmtSerie->execute($paramsSerie);

    foreach ($stmtSerie->fetchAll() as $fila) {
        $fecha = (string) ($fila['fecha'] ?? '');
        if (!array_key_exists($fecha, $visitasPorDia)) {
            continue;
        }

        $visitasPorDia[$fecha] = (int) ($fila['total_visitas'] ?? 0);
        $paisesPorDia[$fecha] = (int) ($fila['total_paises'] ?? 0);
    }

    $labels = [];
    $visitas = [];
    $paisesDistintos = [];
    $diasListado = [];
    foreach ($visitasPorDia as $fecha => $totalVisitas) {
        $label = formatear_label_dia_visita($fecha);
        $totalPaisesDia = (int) ($paisesPorDia[$fecha] ?? 0);

        $labels[] = $label;
        $visitas[] = (int) $totalVisitas;
        $paisesDistintos[] = $totalPaisesDia;
        $diasListado[] = [
            'fecha' => $fecha,
            'label' => $label,
            'visitas' => (int) $totalVisitas,
            'paises_distintos' => $totalPaisesDia,
        ];
    }

    $sqlPaises = 'SELECT COALESCE(NULLIF(TRIM(pais_codigo), \'\'), \'??\') AS pais_codigo,
                         COALESCE(NULLIF(TRIM(pais_nombre), \'\'), \'Desconocido\') AS pais_nombre,
                         COUNT(*) AS total
                  FROM visitas_sitio
                  WHERE pagina = :pagina
                    AND creado_en >= :inicio
                    AND creado_en < :fin_mas_uno'
                  . $wherePaisSql
                  . ' GROUP BY COALESCE(NULLIF(TRIM(pais_codigo), \'\'), \'??\'),
                           COALESCE(NULLIF(TRIM(pais_nombre), \'\'), \'Desconocido\')
                    ORDER BY total DESC, pais_nombre ASC';
    $stmtPaises = $pdo->prepare($sqlPaises);
    $paramsPaises = [
        ':pagina' => $pagina,
        ':inicio' => $inicioSql,
        ':fin_mas_uno' => $finMasUnDiaSql,
    ] + $paramPais;
    $stmtPaises->execute($paramsPaises);

    $paisesListado = [];
    foreach ($stmtPaises->fetchAll() as $filaPais) {
        $codigo = strtoupper(trim((string) ($filaPais['pais_codigo'] ?? '??')));
        if ($codigo === '') {
            $codigo = '??';
        }

        $nombre = trim((string) ($filaPais['pais_nombre'] ?? 'Desconocido'));
        if ($nombre === '') {
            $nombre = 'Desconocido';
        }

        $paisesListado[] = [
            'pais_codigo' => $codigo,
            'pais_nombre' => $nombre,
            'total' => (int) ($filaPais['total'] ?? 0),
        ];
    }

    return [
        'labels' => $labels,
        'visitas' => $visitas,
        'paises_distintos' => $paisesDistintos,
        'dias' => $diasListado,
        'total_periodo' => array_sum($visitas),
        'total_hoy' => (int) ($visitasPorDia[$hoyClave] ?? 0),
        'top_paises' => array_slice($paisesListado, 0, 5),
        'paises' => $paisesListado,
        'fecha_inicio' => $inicio->format('Y-m-d'),
        'fecha_fin' => $fin->format('Y-m-d'),
        'filtro_pais' => $paisCodigoFiltro,
    ];
}
