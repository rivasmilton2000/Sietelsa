<?php
declare(strict_types=1);

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/cache.php';
require_once __DIR__ . '/db_setup.php';

function invalidar_cache_permisos_usuario(): void
{
    iniciar_sesion_segura();
    unset($_SESSION['permisos_cache']);
}

function usuario_actual_es_admin(): bool
{
    iniciar_sesion_segura();
    $perfil = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
    return $perfil === 'admin' || $perfil === 'administrador';
}

function obtener_ruta_pagina_error(int $codigo): ?string
{
    $paginas = [
        401 => __DIR__ . '/../pages/pages_admin/401.html',
        403 => __DIR__ . '/../pages/pages_admin/403.html',
        404 => __DIR__ . '/../pages/pages_admin/404.html',
        500 => __DIR__ . '/../pages/pages_admin/500.html',
    ];

    return $paginas[$codigo] ?? null;
}

function mostrar_pagina_error(int $codigo): void
{
    http_response_code($codigo);

    $ruta = obtener_ruta_pagina_error($codigo);
    if ($ruta !== null && is_file($ruta)) {
        readfile($ruta);
        exit;
    }

    if ($codigo === 401) {
        exit('No autorizado.');
    }

    if ($codigo === 403) {
        exit('Acceso prohibido.');
    }

    if ($codigo === 404) {
        exit('Pagina no encontrada.');
    }

    exit('Error interno del servidor.');
}

function iniciar_sesion_segura(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        if (!isset($_SESSION) || !is_array($_SESSION)) {
            $_SESSION = [];
        }
        return;
    }

    if (headers_sent()) {
        mostrar_pagina_error(500);
    }

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        session_set_cookie_params(0, '/', '', $secure, true);
    }

    if (!session_start()) {
        mostrar_pagina_error(500);
    }

    if (!isset($_SESSION) || !is_array($_SESSION)) {
        $_SESSION = [];
    }
}

function usuario_autenticado(): bool
{
    iniciar_sesion_segura();

    if (!isset($_SESSION['usuario']) || !is_array($_SESSION['usuario'])) {
        return false;
    }

    $id = (int) ($_SESSION['usuario']['id'] ?? 0);
    $email = (string) ($_SESSION['usuario']['email'] ?? '');
    return $id > 0 && $email !== '';
}

function obtener_usuario_actual(): ?array
{
    iniciar_sesion_segura();
    return $_SESSION['usuario'] ?? null;
}

function redirigir(string $ruta): void
{
    header('Location: ' . $ruta);
    exit;
}

function require_login(array $perfilesPermitidos = []): void
{
    $timeoutInactividad = 1800;

    iniciar_sesion_segura();

    if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > $timeoutInactividad) {
        cerrar_sesion();
        redirigir('/admin/login?error=timeout');
    }
    $_SESSION['last_activity'] = time();

    if (!usuario_autenticado()) {
        mostrar_pagina_error(401);
    }

    if (!empty($perfilesPermitidos)) {
        $perfil = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
        $permitidosNormalizados = array_map(static fn (string $item): string => strtolower(trim($item)), $perfilesPermitidos);
        if ($perfil !== 'developer' && !in_array($perfil, $permitidosNormalizados, true)) {
            mostrar_pagina_error(401);
        }
    }
}

function ensure_rbac_runtime(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }

    global $pdo;
    if (!$pdo instanceof PDO) {
        throw new RuntimeException('No hay conexion a base de datos para validar permisos.');
    }

    asegurar_compatibilidad_auth($pdo);
    $ready = true;
}

function permisos_cache_sesion(int $usuarioId, int $perfilId): ?array
{
    $cacheSesion = $_SESSION['permisos_cache'] ?? null;
    if (!is_array($cacheSesion)) {
        return null;
    }

    $cacheTs = (int) ($cacheSesion['ts'] ?? 0);
    $cacheUsuario = (int) ($cacheSesion['usuario_id'] ?? 0);
    $cachePerfil = (int) ($cacheSesion['perfil_id'] ?? 0);
    $cachePermisos = is_array($cacheSesion['permisos'] ?? null) ? $cacheSesion['permisos'] : null;

    if (
        $cacheTs <= (time() - 300)
        || $cacheUsuario !== $usuarioId
        || $cachePerfil !== $perfilId
        || !is_array($cachePermisos)
    ) {
        return null;
    }

    return $cachePermisos;
}

function construir_cache_permisos_usuario(PDO $pdo, int $usuarioId, int $perfilId, bool $esAdmin): array
{
    $permisos = [];

    if (function_exists('tabla_existe') && tabla_existe($pdo, 'modulos') && tabla_existe($pdo, 'perfil_modulo')) {
        $stmt = $pdo->prepare(
            'SELECT m.nombre_modulo,
                    m.estado,
                    COALESCE(pm.aprobado, 0) AS perfil_aprobado,
                    COALESCE(pm_totales.total_aprobados, 0) AS total_aprobados
             FROM modulos m
             LEFT JOIN perfil_modulo pm
                    ON pm.modulo_id = m.id
                   AND pm.perfil_id = :perfil_id
             LEFT JOIN (
                 SELECT modulo_id, SUM(CASE WHEN aprobado = 1 THEN 1 ELSE 0 END) AS total_aprobados
                 FROM perfil_modulo
                 GROUP BY modulo_id
             ) pm_totales ON pm_totales.modulo_id = m.id'
        );
        $stmt->execute([':perfil_id' => $perfilId]);

        foreach ($stmt->fetchAll() as $fila) {
            $codigo = trim((string) ($fila['nombre_modulo'] ?? ''));
            if ($codigo === '') {
                continue;
            }

            $estado = strtolower(trim((string) ($fila['estado'] ?? 'activo')));
            $perfilAprobado = (int) ($fila['perfil_aprobado'] ?? 0) === 1;
            $totalAprobados = (int) ($fila['total_aprobados'] ?? 0);

            if ($estado !== 'activo') {
                $permisos[$codigo] = $esAdmin;
                continue;
            }

            if ($totalAprobados <= 0) {
                $permisos[$codigo] = $esAdmin;
                continue;
            }

            $permisos[$codigo] = $perfilAprobado;
        }
    }

    if (function_exists('tabla_existe') && tabla_existe($pdo, 'permisos')) {
        $tablaUsuarioPermiso = tabla_existe($pdo, 'usuario_permiso');
        $tablaPerfilPermiso = tabla_existe($pdo, 'perfil_permiso');

        if ($tablaUsuarioPermiso || $tablaPerfilPermiso) {
            $sql = 'SELECT p.codigo';
            $params = [];

            if ($tablaUsuarioPermiso) {
                $sql .= ', up.permitido AS usuario_permitido';
            } else {
                $sql .= ', NULL AS usuario_permitido';
            }

            if ($tablaPerfilPermiso) {
                $sql .= ', CASE WHEN pp.perfil_id IS NULL THEN 0 ELSE 1 END AS perfil_permitido';
            } else {
                $sql .= ', 0 AS perfil_permitido';
            }

            $sql .= ' FROM permisos p';

            if ($tablaUsuarioPermiso) {
                $sql .= ' LEFT JOIN usuario_permiso up
                          ON up.permiso_id = p.id
                         AND up.usuario_id = :usuario_id';
                $params[':usuario_id'] = $usuarioId;
            }

            if ($tablaPerfilPermiso) {
                $sql .= ' LEFT JOIN perfil_permiso pp
                          ON pp.permiso_id = p.id
                         AND pp.perfil_id = :perfil_id';
                $params[':perfil_id'] = $perfilId;
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            foreach ($stmt->fetchAll() as $fila) {
                $codigo = trim((string) ($fila['codigo'] ?? ''));
                if ($codigo === '' || array_key_exists($codigo, $permisos)) {
                    continue;
                }

                $usuarioPermitido = $fila['usuario_permitido'] ?? null;
                if ($usuarioPermitido !== null && $usuarioPermitido !== '') {
                    $permisos[$codigo] = (int) $usuarioPermitido === 1;
                    continue;
                }

                $permisos[$codigo] = (int) ($fila['perfil_permitido'] ?? 0) === 1;
            }
        }
    }

    return $permisos;
}

function tiene_permiso(string $codigoPermiso): bool
{
    global $pdo;
    static $cacheRequest = [];

    $codigoPermiso = trim($codigoPermiso);
    if ($codigoPermiso === '') {
        return false;
    }

    if (!usuario_autenticado()) {
        return false;
    }

    $usuarioId = (int) ($_SESSION['usuario']['id'] ?? 0);
    $perfilId = (int) ($_SESSION['usuario']['perfil_id'] ?? 0);
    $perfilNombre = strtolower(trim((string) ($_SESSION['usuario']['perfil'] ?? '')));
    if ($usuarioId <= 0) {
        return false;
    }

    if ($perfilId <= 0) {
        return false;
    }

    $esAdmin = ($perfilNombre === 'admin' || $perfilNombre === 'administrador');
    ensure_rbac_runtime();

    $cacheRequestKey = $usuarioId . '|' . $perfilId . '|' . $codigoPermiso;
    if (array_key_exists($cacheRequestKey, $cacheRequest)) {
        return (bool) $cacheRequest[$cacheRequestKey];
    }

    $cachePermisos = permisos_cache_sesion($usuarioId, $perfilId);
    if ($cachePermisos === null) {
        $cachePermisos = construir_cache_permisos_usuario($pdo, $usuarioId, $perfilId, $esAdmin);
        $_SESSION['permisos_cache'] = [
            'ts' => time(),
            'usuario_id' => $usuarioId,
            'perfil_id' => $perfilId,
            'permisos' => $cachePermisos,
        ];
    }

    $permitido = (bool) ($cachePermisos[$codigoPermiso] ?? false);
    $cacheRequest[$cacheRequestKey] = $permitido;

    return $permitido;
}

function require_admin(): void
{
    require_login();
    if (!usuario_actual_es_admin()) {
        mostrar_pagina_error(403);
    }
}

function require_modulo(string $codigoModulo, bool $soloAdmin = false): void
{
    require_login();
    ensure_rbac_runtime();

    if ($soloAdmin && !usuario_actual_es_admin()) {
        mostrar_pagina_error(403);
    }

    if (!tiene_permiso($codigoModulo)) {
        mostrar_pagina_error(403);
    }
}

function require_permiso(string $codigoPermiso): void
{
    require_modulo($codigoPermiso);
}

function cerrar_sesion(): void
{
    iniciar_sesion_segura();
    invalidar_cache_permisos_usuario();
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}
