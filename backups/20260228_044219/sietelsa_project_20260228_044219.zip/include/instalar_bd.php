<?php
declare(strict_types=1);

require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/db_setup.php';

global $pdo;

try {
    asegurar_compatibilidad_auth($pdo);
} catch (Throwable $e) {
    sietelsa_log('Error installing auth schema', ['message' => $e->getMessage()]);
    http_response_code(500);
    exit('Error interno del servidor.');
}

header('Location: /admin/login?ok=instalado');
exit;
