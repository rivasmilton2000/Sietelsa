<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

function admin_sidebar_slug(string $valor): string
{
    $valor = strtolower(trim($valor));
    $valor = preg_replace('/[^a-z0-9_]+/', '_', $valor) ?? '';
    $valor = trim($valor, '_');

    return $valor;
}

function admin_sidebar_label_modulo(string $codigoModulo): string
{
    $codigo = admin_sidebar_slug($codigoModulo);
    if ($codigo === '') {
        return 'Modulo';
    }

    if (str_starts_with($codigo, 'gestionar_')) {
        $codigo = substr($codigo, strlen('gestionar_'));
    } elseif (str_starts_with($codigo, 'ver_')) {
        $codigo = substr($codigo, strlen('ver_'));
    }

    $label = trim(str_replace('_', ' ', $codigo));
    if ($label === '') {
        $label = admin_sidebar_slug($codigoModulo);
    }

    return ucwords($label);
}

function admin_sidebar_ruta_modulo(string $codigoModulo): string
{
    $codigo = admin_sidebar_slug($codigoModulo);
    if ($codigo === '' || $codigo === 'ver_dashboard') {
        return '/admin/dashboard';
    }

    if (str_starts_with($codigo, 'gestionar_')) {
        $codigo = substr($codigo, strlen('gestionar_'));
    } elseif (str_starts_with($codigo, 'ver_')) {
        $codigo = substr($codigo, strlen('ver_'));
    }

    $segmento = str_replace('_', '-', $codigo);
    if ($segmento === '') {
        return '/admin/dashboard';
    }

    return '/admin/' . $segmento;
}

function admin_sidebar_icono_modulo(string $codigoModulo): string
{
    $codigo = admin_sidebar_slug($codigoModulo);

    if (str_contains($codigo, 'reporte')) {
        return 'fa-chart-column';
    }

    if (str_contains($codigo, 'usuario')) {
        return 'fa-users';
    }

    if (str_contains($codigo, 'backup')) {
        return 'fa-database';
    }

    return 'fa-puzzle-piece';
}

function admin_sidebar_catalogo(PDO $pdo): array
{
    $catalogo = [
        [
            'seccion' => 'principal',
            'permiso' => 'ver_dashboard',
            'ruta' => '/admin/dashboard',
            'label' => 'Dashboard',
            'icono' => 'fa-tachometer-alt',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_usuarios',
            'ruta' => '/admin/usuarios/registro',
            'label' => 'Registrar usuario',
            'icono' => 'fa-user-plus',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_usuarios',
            'ruta' => '/admin/usuarios/editar',
            'label' => 'Editar usuarios',
            'icono' => 'fa-user-gear',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_usuarios',
            'ruta' => '/admin/usuarios/eliminar',
            'label' => 'Eliminar usuarios',
            'icono' => 'fa-user-minus',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_perfiles',
            'ruta' => '/admin/perfiles',
            'label' => 'Tipos de perfil',
            'icono' => 'fa-id-badge',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_servicios',
            'ruta' => '/admin/servicios',
            'label' => 'Gestionar servicios',
            'icono' => 'fa-screwdriver-wrench',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_portafolio',
            'ruta' => '/admin/portafolio',
            'label' => 'Gestionar portafolio',
            'icono' => 'fa-images',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_proyectos',
            'ruta' => '/admin/proyectos',
            'label' => 'Gestionar proyectos',
            'icono' => 'fa-diagram-project',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_nosotros',
            'ruta' => '/admin/nosotros',
            'label' => 'Gestionar nosotros',
            'icono' => 'fa-building',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_contacto',
            'ruta' => '/admin/contacto',
            'label' => 'Mensajes contacto',
            'icono' => 'fa-envelope-open-text',
        ],
        [
            'seccion' => 'administracion',
            'permiso' => 'gestionar_backup',
            'ruta' => '/admin/backup',
            'label' => 'Backup BD',
            'icono' => 'fa-database',
        ],
    ];

    $permisosBase = [];
    foreach ($catalogo as $item) {
        $permiso = trim((string) ($item['permiso'] ?? ''));
        if ($permiso !== '') {
            $permisosBase[$permiso] = true;
        }
    }

    if (function_exists('tabla_existe') && tabla_existe($pdo, 'modulos')) {
        $stmt = $pdo->query(
            "SELECT nombre_modulo
             FROM modulos
             WHERE estado = 'activo'
             ORDER BY fecha_creacion ASC, id ASC"
        );

        $modulos = $stmt ? $stmt->fetchAll(PDO::FETCH_COLUMN) : [];
        foreach ($modulos as $codigoRaw) {
            $codigo = admin_sidebar_slug((string) $codigoRaw);
            if ($codigo === '' || isset($permisosBase[$codigo])) {
                continue;
            }

            $catalogo[] = [
                'seccion' => 'modulos',
                'permiso' => $codigo,
                'ruta' => admin_sidebar_ruta_modulo($codigo),
                'label' => admin_sidebar_label_modulo($codigo),
                'icono' => admin_sidebar_icono_modulo($codigo),
            ];
        }
    }

    return $catalogo;
}

function render_admin_sidebar(PDO $pdo, array $usuarioActual, string $etiquetaSesion): void
{
    $rutaActual = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: '');
    $catalogo = admin_sidebar_catalogo($pdo);
    $sesionEsAdmin = usuario_actual_es_admin();

    $principal = [];
    $administracion = [];
    $modulosDinamicos = [];

    foreach ($catalogo as $item) {
        $permiso = (string) ($item['permiso'] ?? '');
        if ($permiso === 'gestionar_perfiles' && !$sesionEsAdmin) {
            continue;
        }

        if ($permiso === '' || !tiene_permiso($permiso)) {
            continue;
        }

        if (($item['seccion'] ?? '') === 'principal') {
            $principal[] = $item;
            continue;
        }

        if (($item['seccion'] ?? '') === 'modulos') {
            $modulosDinamicos[] = $item;
            continue;
        }

        $administracion[] = $item;
    }
    ?>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Principal</div>
                    <?php foreach ($principal as $item): ?>
                        <a class="nav-link <?php echo $rutaActual === $item['ruta'] ? 'active' : ''; ?>" href="<?php echo htmlspecialchars((string) $item['ruta'], ENT_QUOTES, 'UTF-8'); ?>">
                            <div class="sb-nav-link-icon"><i class="fas <?php echo htmlspecialchars((string) $item['icono'], ENT_QUOTES, 'UTF-8'); ?>"></i></div>
                            <?php echo htmlspecialchars((string) $item['label'], ENT_QUOTES, 'UTF-8'); ?>
                        </a>
                    <?php endforeach; ?>

                    <?php if (!empty($administracion)): ?>
                        <div class="sb-sidenav-menu-heading">Administracion</div>
                        <?php foreach ($administracion as $item): ?>
                            <a class="nav-link <?php echo $rutaActual === $item['ruta'] ? 'active' : ''; ?>" href="<?php echo htmlspecialchars((string) $item['ruta'], ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="sb-nav-link-icon"><i class="fas <?php echo htmlspecialchars((string) $item['icono'], ENT_QUOTES, 'UTF-8'); ?>"></i></div>
                                <?php echo htmlspecialchars((string) $item['label'], ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php if (!empty($modulosDinamicos)): ?>
                        <div class="sb-sidenav-menu-heading">Modulos</div>
                        <?php foreach ($modulosDinamicos as $item): ?>
                            <a class="nav-link <?php echo $rutaActual === $item['ruta'] ? 'active' : ''; ?>" href="<?php echo htmlspecialchars((string) $item['ruta'], ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="sb-nav-link-icon"><i class="fas <?php echo htmlspecialchars((string) $item['icono'], ENT_QUOTES, 'UTF-8'); ?>"></i></div>
                                <?php echo htmlspecialchars((string) $item['label'], ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Sesion iniciada:</div>
                <?php echo htmlspecialchars($etiquetaSesion, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        </nav>
    </div>
    <?php
}
