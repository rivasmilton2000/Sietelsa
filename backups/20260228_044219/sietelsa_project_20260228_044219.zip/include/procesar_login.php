<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db_setup.php';
require_once __DIR__ . '/recaptcha.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/rate_limit.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirigir('/admin/login');
}

$identificador = trim((string) ($_POST['identificador'] ?? $_POST['email'] ?? ''));
$password = (string) ($_POST['password'] ?? '');
$recaptchaToken = trim((string) ($_POST['g-recaptcha-response'] ?? ''));
$csrfToken = trim((string) ($_POST['csrf_token'] ?? ''));
$remoteIp = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
$rateKey = $remoteIp !== '' ? $remoteIp : 'desconocido';
$rateStatus = sietelsa_rate_limit_guard('admin_login', $rateKey, 5, 900);

if (!$rateStatus['allowed']) {
    header('Retry-After: ' . (string) $rateStatus['retry_after']);
    redirigir('/admin/login?error=rate_limit');
}

if (!csrf_token_valido($csrfToken, 'admin_login')) {
    sietelsa_rate_limit_register_fail('admin_login', $rateKey, 900);
    redirigir('/admin/login?error=csrf');
}

if ($identificador === '' || $password === '') {
    sietelsa_rate_limit_register_fail('admin_login', $rateKey, 900);
    redirigir('/admin/login?error=campos');
}

if (!recaptcha_configurada()) {
    redirigir('/admin/login?error=captcha_config');
}

if ($recaptchaToken === '') {
    sietelsa_rate_limit_register_fail('admin_login', $rateKey, 900);
    redirigir('/admin/login?error=captcha');
}

if (!validar_recaptcha($recaptchaToken, $remoteIp)) {
    sietelsa_rate_limit_register_fail('admin_login', $rateKey, 900);
    redirigir('/admin/login?error=captcha');
}

global $pdo;

$sql = 'SELECT u.id, u.nombre, u.username, u.email, u.password_hash, u.activo, u.perfil_id, p.nombre AS perfil
        FROM usuarios u
        INNER JOIN perfiles p ON p.id = u.perfil_id
        WHERE (u.email = :identificador_email OR u.username = :identificador_username)
        LIMIT 1';

$ejecutarConsultaUsuario = static function () use ($pdo, $sql, $identificador): array|false {
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':identificador_email' => $identificador,
        ':identificador_username' => $identificador,
    ]);
    return $stmt->fetch();
};

try {
    $usuario = $ejecutarConsultaUsuario();
} catch (PDOException $e) {
    $sqlState = $e->errorInfo[0] ?? '';

    if ($sqlState === '42S02' || $sqlState === '42S22') {
        try {
            asegurar_compatibilidad_auth($pdo);
            $usuario = $ejecutarConsultaUsuario();
        } catch (Throwable $e2) {
            sietelsa_log('Login schema compatibility error', ['message' => $e2->getMessage()]);
            redirigir('/admin/login?error=estructura');
        }
    } else {
        sietelsa_log('Login DB error', ['message' => $e->getMessage(), 'sql_state' => $sqlState]);
        http_response_code(500);
        exit('Error interno del servidor.');
    }
}

if (!$usuario || (int) $usuario['activo'] !== 1 || !password_verify($password, $usuario['password_hash'])) {
    sietelsa_rate_limit_register_fail('admin_login', $rateKey, 900);
    redirigir('/admin/login?error=credenciales');
}

sietelsa_rate_limit_clear('admin_login', $rateKey);

iniciar_sesion_segura();
session_regenerate_id(true);
invalidar_cache_permisos_usuario();
$_SESSION = [];

$_SESSION['usuario'] = [
    'id' => (int) $usuario['id'],
    'nombre' => $usuario['nombre'],
    'username' => $usuario['username'],
    'email' => $usuario['email'],
    'perfil_id' => (int) $usuario['perfil_id'],
    'perfil' => $usuario['perfil'],
];
$_SESSION['last_activity'] = time();

redirigir('/admin/dashboard');
