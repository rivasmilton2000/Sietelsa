<?php
declare(strict_types=1);

require_once __DIR__ . '/db_setup.php';

function usuario_puede_gestionar_mantenimiento(?array $usuario): bool
{
    if (!is_array($usuario)) {
        return false;
    }

    $perfil = strtolower(trim((string) ($usuario['perfil'] ?? '')));
    return in_array($perfil, ['admin', 'developer'], true);
}

function usuario_puede_bypass_mantenimiento(?array $usuario): bool
{
    return usuario_puede_gestionar_mantenimiento($usuario);
}

function mantenimiento_esta_activo(PDO $pdo): bool
{
    static $cache = null;
    if (is_bool($cache)) {
        return $cache;
    }

    asegurar_tabla_configuracion_sistema($pdo);

    $stmt = $pdo->prepare('SELECT valor FROM configuracion_sistema WHERE clave = :clave LIMIT 1');
    $stmt->execute([':clave' => 'mantenimiento_activo']);
    $valor = trim((string) ($stmt->fetchColumn() ?: '0'));

    $cache = ($valor === '1');
    return $cache;
}

function mantenimiento_actualizar_estado(PDO $pdo, bool $activo): void
{
    asegurar_tabla_configuracion_sistema($pdo);

    $stmt = $pdo->prepare(
        'INSERT INTO configuracion_sistema (clave, valor)
         VALUES (:clave, :valor)
         ON DUPLICATE KEY UPDATE valor = VALUES(valor), actualizado_en = CURRENT_TIMESTAMP'
    );
    $stmt->execute([
        ':clave' => 'mantenimiento_activo',
        ':valor' => $activo ? '1' : '0',
    ]);
}
