<?php
declare(strict_types=1);

function sietelsa_asset_url(string $ruta): string
{
    $ruta = ltrim(str_replace('\\', '/', trim($ruta)), '/');
    if ($ruta === '') {
        return '';
    }

    $absoluta = __DIR__ . '/../' . $ruta;
    $version = is_file($absoluta) ? (string) filemtime($absoluta) : (string) time();

    $sep = strpos($ruta, '?') === false ? '?' : '&';
    return $ruta . $sep . 'v=' . rawurlencode($version);
}
