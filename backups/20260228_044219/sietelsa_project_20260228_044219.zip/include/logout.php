<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

cerrar_sesion();
redirigir('/admin/login?ok=logout');
